// expose
window['Shadowbox'] = S;

})(window);
